package io.mockit.ide;

import org.eclipse.ui.IStartup;

public class Startup implements IStartup {

	/**
	 * We need to participate in the startup in order to start this plugins {@link Activator}
	 * indirectly by the OSGi framework.
	 * 
	 */
	@Override
	public void earlyStartup() {
	}

}
