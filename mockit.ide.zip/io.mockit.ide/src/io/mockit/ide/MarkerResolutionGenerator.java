package io.mockit.ide;

import static io.mockit.ide.checker.MockitoProblemType.MOCKITO_PROBLEM_TYPE;
import static org.eclipse.core.resources.IMarker.LINE_NUMBER;
import static org.eclipse.core.resources.IMarker.SOURCE_ID;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.swt.graphics.Image;
import org.eclipse.ui.IMarkerResolution;
import org.eclipse.ui.IMarkerResolution2;
import org.eclipse.ui.IMarkerResolutionGenerator;
import org.eclipse.ui.IMarkerResolutionGenerator2;

import io.mockit.ide.checker.MockitoProblemType;

public class MarkerResolutionGenerator implements IMarkerResolutionGenerator2 {

	private final static IMarkerResolution[] empty = new IMarkerResolution[0];

	public IMarkerResolution[] getResolutions(IMarker marker) {
		
			return new IMarkerResolution2[] {new IMarkerResolution2() {
				
				@Override
				public void run(IMarker marker) {
				}
				
				@Override
				public String getLabel() {
					return "Remove Mockito Runner";
				}
				
				@Override
				public Image getImage() {
					return null;
				}
				
				@Override
				public String getDescription() {
					return null;
				}
			}};

	}

	@Override
	public boolean hasResolutions(IMarker marker) {
		if (!marker.exists()) {
			return false;
		}

		
		try {
			if (!"mockitoChecker".equals(marker.getAttribute(SOURCE_ID))) {
				return false;
			}

			
			MockitoProblemType type = (MockitoProblemType) marker.getAttribute(MOCKITO_PROBLEM_TYPE);
			
			return true;
		} catch (CoreException markerDoesntExist) {
			return false;
		}
	}

}
