package io.mockit.ide.builder;

import static org.eclipse.core.runtime.IProgressMonitor.UNKNOWN;
import static org.eclipse.jdt.core.IPackageFragmentRoot.K_SOURCE;
import static org.eclipse.jdt.core.dom.AST.JLS8;
import static org.eclipse.jdt.core.dom.ASTParser.K_COMPILATION_UNIT;

import java.util.Map;

import org.eclipse.core.resources.IProject;
import org.eclipse.core.resources.IncrementalProjectBuilder;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.core.runtime.IProgressMonitor;
import org.eclipse.jdt.core.ICompilationUnit;
import org.eclipse.jdt.core.IJavaProject;
import org.eclipse.jdt.core.IPackageFragment;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaCore;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.ASTParser;
import org.eclipse.jdt.core.dom.CompilationUnit;

import io.mockit.ide.checker.IChecker;
import io.mockit.ide.checker.RunnerAndRuleChecker;

public class MockitoCheckBuilder extends IncrementalProjectBuilder {

	@Override
	protected IProject[] build(int kind, Map<String, String> args, IProgressMonitor monitor) throws CoreException {
		monitor.beginTask("Checking Mockito usage.", UNKNOWN);
		
		IProject project = getProject();

		IJavaProject javaProject = JavaCore.create(project);
		IPackageFragment[] packages = javaProject.getPackageFragments();

		checkPackageFragments(monitor, packages);

		monitor.done();
		return new IProject[] { project };
	}

	private void checkPackageFragments(IProgressMonitor monitor, IPackageFragment[] packages)
			throws JavaModelException, CoreException {
		for (IPackageFragment packageFragment : packages) {
			if (packageFragment.getKind() == K_SOURCE && packageFragment.exists() && packageFragment.isOpen()) {

				for (final ICompilationUnit compilationUnit : packageFragment.getCompilationUnits()) {
					if (monitor.isCanceled())
						return;
					CompilationUnit cu = parse(compilationUnit);
					IType[] topLevelTypes = compilationUnit.getTypes();
					checkTopLevelTypes(topLevelTypes,cu);
				}
			}
		}
	}

	private void checkTopLevelTypes(IType[] topLevelTypes, CompilationUnit cu) throws CoreException {
		for (IType topLevelType : topLevelTypes) {
			if (topLevelType.isClass()) {
					checkType(topLevelType,cu);
					new Runnable() {
						
						@Override
						public void run() {
							
						}
					};
			}
		}
	}

	private void checkType(IType type, CompilationUnit cu) throws CoreException {
		IChecker checker = new RunnerAndRuleChecker();
		checker.checkClass(type,cu);
	}
	
	private static CompilationUnit parse(ICompilationUnit unit) {
		ASTParser parser = ASTParser.newParser(JLS8);
		parser.setKind(K_COMPILATION_UNIT);
		parser.setSource(unit); // set source
		parser.setResolveBindings(true); // we need bindings later on
		return (CompilationUnit) parser.createAST(null /* IProgressMonitor */); // parse
	}
}