package io.mockit.ide.checker;

import java.util.List;

import org.eclipse.jdt.core.dom.ASTVisitor;
import org.eclipse.jdt.core.dom.FieldDeclaration;
import org.eclipse.jdt.core.dom.IExtendedModifier;
import org.eclipse.jdt.core.dom.ITypeBinding;
import org.eclipse.jdt.core.dom.MarkerAnnotation;
import org.eclipse.jdt.core.dom.Modifier;

final class VisitorHasMockioRule extends ASTVisitor {
	private boolean hasValidMockitoRule;

	VisitorHasMockioRule( ) {
		super(false);
	}

	@Override
	public boolean visit(final FieldDeclaration node) {
		if (hasValidMockitoRule == true) { 
			// we already found a valid mockito rule
			return false;
		}

		if (hasExpectedModifiers(node) && isTypeMockioRule(node)) {
			hasValidMockitoRule= true;
		}

		return false;
	}

	private boolean isTypeMockioRule(final FieldDeclaration node) {
		String qualifiedName = node.getType().resolveBinding().getQualifiedName();
		switch (qualifiedName) {
		case "org.mockito.junit.MockitoRule":
			return true;
		}

		return false;
	}

	@SuppressWarnings("unchecked")
	private boolean hasExpectedModifiers(final FieldDeclaration node) {
		boolean hasRuleAnnotation = false;
		boolean isPublic = false;
		boolean isStatic = false;

		List<IExtendedModifier> modifiers = node.modifiers();
		for (IExtendedModifier modifier : modifiers) {
			if (!hasRuleAnnotation) {
				hasRuleAnnotation = isJUnitRuleAnnotation(modifier);
			}
			if (!isPublic) {
				isPublic = isPublic(modifier);
			}
			if (!isStatic) {
				isStatic = isStatic(modifier);
			}
		}

		return hasRuleAnnotation && isPublic && !isStatic;
	}

	private boolean isPublic(IExtendedModifier modifier) {
		if (!(modifier instanceof Modifier)) {
			return false;
		}
		Modifier m = (Modifier) modifier;

		return m.isPublic();
	}

	private boolean isStatic(IExtendedModifier modifier) {
		if (!(modifier instanceof Modifier)) {
			return false;
		}
		Modifier m = (Modifier) modifier;

		return m.isStatic();
	}

	private boolean isJUnitRuleAnnotation(IExtendedModifier modifier) {
		if (!(modifier instanceof MarkerAnnotation)) {
			return false;
		}

		MarkerAnnotation a = (MarkerAnnotation) modifier;

		ITypeBinding typeName = a.resolveTypeBinding();
		String qualifiedName = typeName.getQualifiedName();
		return "org.junit.Rule".equals(qualifiedName);

	}

	public boolean foundValidMockitoRule() {
		return hasValidMockitoRule;
	}
}