package io.mockit.ide.checker;

import static io.mockit.ide.checker.MockitoProblemType.MOCKITO_PROBLEM_TYPE;
import static io.mockit.ide.checker.MockitoProblemType.UNNECCESSARY_MOCKITO_RULE;
import static java.util.Optional.empty;
import static org.eclipse.core.resources.IMarker.LINE_NUMBER;
import static org.eclipse.core.resources.IMarker.MESSAGE;
import static org.eclipse.core.resources.IMarker.SEVERITY;
import static org.eclipse.core.resources.IMarker.SEVERITY_WARNING;
import static org.eclipse.core.resources.IMarker.SOURCE_ID;
import static org.eclipse.jdt.core.IJavaModelMarker.JAVA_MODEL_PROBLEM_MARKER;
import static org.eclipse.jdt.core.IMemberValuePair.K_CLASS;

import java.util.Optional;

import org.eclipse.core.resources.IMarker;
import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.IAnnotation;
import org.eclipse.jdt.core.IJavaModelMarker;
import org.eclipse.jdt.core.IMemberValuePair;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.JavaModelException;
import org.eclipse.jdt.core.dom.CompilationUnit;

public class RunnerAndRuleChecker implements IChecker {



	@Override
	public void checkClass(IType type,CompilationUnit unit) throws CoreException {
		Optional<ProblemLocation> hasMockitoRunner = hasMockitoRunner(type, unit);
		
		if (hasMockitoRunner.isPresent() && hasMockitoRule(type, unit)) {
			IMarker problem = type.getResource().createMarker("io.mockit.ide.marker.problem");
			problem.setAttribute(SEVERITY, SEVERITY_WARNING);
			problem.setAttribute(MESSAGE, "Can be removed cause MockitoRule is already in place.");
			problem.setAttribute(LINE_NUMBER, hasMockitoRunner.get().line);
			problem.setAttribute(SOURCE_ID, "mockitoChecker");
			problem.setAttribute(MOCKITO_PROBLEM_TYPE, UNNECCESSARY_MOCKITO_RULE);
		}
	}

	private static boolean hasMockitoRule(IType type, CompilationUnit unit) throws JavaModelException {
		VisitorHasMockioRule visitor = new VisitorHasMockioRule();
		unit.accept(visitor);
		
		return visitor.foundValidMockitoRule();
	}

	

	private static Optional<ProblemLocation> hasMockitoRunner(IType type, CompilationUnit unit)
			throws JavaModelException {
		IAnnotation runWithAnnotation = getRunWithAnnotation(type);

		if (!runWithAnnotation.exists())
			return empty();

		if (hasMockitoRunner(runWithAnnotation)) {
			ProblemLocation location = new ProblemLocation();
			int offset = runWithAnnotation.getSourceRange().getOffset();
			
			location.line = unit.getLineNumber(offset);

			return Optional.of(location);
		}

		return empty();

	}

	private static boolean hasMockitoRunner(IAnnotation runWithAnnotation) throws JavaModelException {
		String name = getRunnerName(runWithAnnotation);

		if (name == null)
			return false;
		return name.equals("MockitoJUnitRunner") || name.equals("org.mockito.runners.MockitoJUnitRunner");
	}

	private static IAnnotation getRunWithAnnotation(IType type) {
		IAnnotation runWithAnnotation = type.getAnnotation("RunWith");
		if (runWithAnnotation.exists()) {
			return runWithAnnotation;

		}
		return type.getAnnotation("org.junit.runner.RunWith");
	}

	private static String getRunnerName(IAnnotation runWithAnnotation) throws JavaModelException {
		IMemberValuePair[] pairs = runWithAnnotation.getMemberValuePairs();
		for (IMemberValuePair pair : pairs) {
			if ("value".equals(pair.getMemberName()) && pair.getValueKind() == K_CLASS) {
				String runnerName = (String) pair.getValue();
				return runnerName;
			}
		}
		return null;
	}

	static class ProblemLocation {
		public int line = -1;

		@Override
		public String toString() {
			return "line="+line;
		}
	}

}
