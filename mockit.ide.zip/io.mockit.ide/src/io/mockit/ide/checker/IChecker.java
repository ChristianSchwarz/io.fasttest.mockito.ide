package io.mockit.ide.checker;

import org.eclipse.core.runtime.CoreException;
import org.eclipse.jdt.core.IType;
import org.eclipse.jdt.core.dom.CompilationUnit;

public interface IChecker {

	void checkClass(IType type, CompilationUnit unit) throws CoreException;
}
