package io.mockit.ide.checker;

public enum MockitoProblemType {
	
	
	UNNECCESSARY_MOCKITO_RULE;
	
	public final static String MOCKITO_PROBLEM_TYPE = "MockitoProblemType";
}
